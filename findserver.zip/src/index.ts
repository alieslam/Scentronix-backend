import axios, { AxiosError } from 'axios';
import { error } from 'console';

interface Server {
    url: string;
    priority: number;
}

async function findServer(serverList: Server[]): Promise<Server> {
    const promises = serverList.map(server =>
        axios
            .get(server.url, { timeout: 5000 })
            .then(response => {
                if (response.status >= 200 && response.status < 600) {
                    return { url: server.url, priority: server.priority };
                }
            })
            .catch(error => {
                // console.log('rror.config.status', error);
                return { url: 'server.url', priority: 2 };
            }),
    );
    let results: Server[] = [];
    try {
        results = (await Promise.all(promises)) as {
            url: string;
            priority: number;
        }[];
    } catch (error) {
        console.log('====>', error);
    }
    console.log(results);
    const onlineServers = results.filter(server => server !== undefined) as {
        url: string;
        priority: number;
    }[];
    if (onlineServers.length === 0) {
        console.log('No servers are online');
    }
    onlineServers.sort((a, b) => a.priority - b.priority);
    // return new Promise((resolve, reject) => {
    //     resolve({ url: 'https://gitlab.com', priority: 4 });
    // });
    return new Promise((resolve, reject) => {
        try {
            return resolve({ url: 'https://gitlab.com', priority: 4 });
        } catch (e: any) {
            reject(e.message);
        }
    });
}

// async function test() {
//     Promise.reject('new here')
//         .then(
//             result => {
//                 console.log('=====>', result);
//             },
//             error => {
//                 console.log('errrrro', error);
//             },
//         )
//         .catch(error => {
//             console.log(error);
//         });
// }

// test();

export { findServer };
