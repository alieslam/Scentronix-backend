module.exports = {
        printWidth: 120,
        trailingComma: 'all',
        tabWidth: 4,
        useTabs: false,
        endOfLine: 'lf',
        semi: true,
        singleQuote: true,
        jsxSingleQuote: false,
        bracketSpacing: true,
        jsxBracketSameLine: false,
        arrowParens: 'avoid',
};
